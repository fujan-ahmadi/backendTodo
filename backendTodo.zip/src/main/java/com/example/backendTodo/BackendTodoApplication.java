package com.example.backendTodo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendTodoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendTodoApplication.class, args);
	}

}
